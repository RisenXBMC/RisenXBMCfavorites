plugin.audio.musicbox
=====================

Music box is a new way to listen and discover music thought XBMC
